import { SafeAreaView,StyleSheet, Text, View , Alert, TouchableOpacity } from 'react-native';
import React , {useState,useMemo} from 'react';
import SeatGrid from './components/SeatGrid';

export default function App() {
  const [seats, setSeat] = useState(() => 
      Array.from({length:20}, (_,i) => ({ id: i+1, status:'available'}))
  );

  const toggleSeat = (id) => {
    setSeat(prev =>
        prev.map(s=> (s.id ===id ? {...s, status:s.status=== 'availbale' ? 'booked' : 'available'} : s))
    );
  };

  const bookedSeats = useMemo(() => seats.filter(s => s.status === 'booked').map(s=>s.id), [seats]);

  const handleConfirm = () => {
    if(bookedSeats.length===0){
      Alert.alert('Thongbao','Ban chua chon ghe nao');
      return;
    }
    Alert.alert('ThanhCong','Ban da dat cho');
  };

  return(
    <SafeAreaView style = {styles.safe}>
      <View style = {styles.container}>
        <Text style = {styles.title}> Rap chieu phim-Dat ghe </Text>
        <View style ={styles.screenWrap}>
          
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
