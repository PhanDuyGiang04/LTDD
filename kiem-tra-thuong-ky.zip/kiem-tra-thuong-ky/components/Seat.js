import { Text, StyleSheet, Pressable } from 'react-native';
import React from 'react';

const Seat = ({ id, status= 'available', onPress}) => {
  const backgroundColor = status === 'booked' ? '#e74c3c' : '#2ecc71';
  const textColor = '#fff';

 return(
   <Pressable style = {[style.seat, {backgroundColor}]}
    onPress= {() =>onPress && onPress(id)}
    android_ripple = {{color:'rgba(255,255,255,0.2'}}
    >
    <Text style= {[styles.label,{color:textColor}]}>{id}</Text>
   </Pressable>
 ); 
};

const styles = StyleSheet.create({
  seat:{
    width:60,
    height:60,
    margin:6,
    borderRadius:8,
    justifyContent:'center',
    alignItems:'center',
    elevation:2
  
  },
  label:{
    fontSize:16,
    fontWeight:'700'
  }
});

export default Seat;
