import React from 'react';
import {View, StyleSheet} from 'react-native';
import Seat from './Seat';

const SeatGrid = ({ seats = [] , onToggle}) =>{
  return (
    <View style = {style.wrap}>
     {seats.map(seat => (
       <Seat key={seat.id} id = {seat.id} status = {seat.status} onPress= {onToggle} />
     ))}
    </View>
  );
};

const styles = StyleSheet.create({
  wrap : {
    width  :'95%',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent : 'center',
    alignItems: 'center',
    marginTop : 8,
    paddingVertical: 8, 
    backgroundColor:'transparent'
  }
});