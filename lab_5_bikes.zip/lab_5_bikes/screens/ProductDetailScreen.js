import React from "react";
import { View, Text, Image, StyleSheet, TouchableOpacity, ScrollView } from "react-native";

export default function ProductDetailScreen({ route, navigation }) {
  const { product } = route.params;

  return (
    <ScrollView style={styles.container}>
      {/* Image */}
      <View style={styles.imageBox}>
        <Image source={product.img} style={styles.image} resizeMode="contain" />
      </View>

      {/* Name + Price */}
      <Text style={styles.name}>{product.name}</Text>
      <Text style={styles.discount}>{product.discount} | ${product.price}</Text>
      <Text style={styles.oldPrice}>${product.oldPrice}</Text>

      {/* Description */}
      <Text style={styles.sectionTitle}>Description</Text>
      <Text style={styles.desc}>{product.desc}</Text>

      {/* Button */}
      <TouchableOpacity
        style={styles.addButton}
        onPress={() => {
          // xử lý thêm vào giỏ hàng (tạm thời chỉ quay về Home)
          navigation.goBack();
        }}
      >
        <Text style={styles.addButtonText}>Add to Cart</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", padding: 15 },
  imageBox: {
    backgroundColor: "#ffeef2",
    borderWidth: 1,
    borderColor: "white",
    borderRadius: 10,
    padding: 20,
    alignItems: "center",
    marginBottom: 20,
  },
  image: { width: 250, height: 200 },
  name: { fontSize: 20, fontWeight: "bold", marginBottom: 10 },
  discount: { fontSize: 14, color: "orange", fontWeight: "bold" },
  oldPrice: {
    fontSize: 14,
    color: "#666",
    textDecorationLine: "line-through",
    marginBottom: 20,
  },
  sectionTitle: { fontSize: 16, fontWeight: "bold", marginBottom: 8 },
  desc: { fontSize: 14, color: "#555", marginBottom: 30 },
  addButton: {
    backgroundColor: "#ff4d4d",
    paddingVertical: 15,
    borderRadius: 30,
    alignItems: "center",
    marginBottom: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 4, // Android shadow
  },
  addButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
    textTransform: "uppercase",
  },
});
