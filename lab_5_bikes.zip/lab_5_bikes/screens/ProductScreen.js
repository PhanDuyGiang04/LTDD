import React from "react";
import { View, Text, TouchableOpacity, FlatList, Image, StyleSheet } from "react-native";

const bikes = [
  { id: "1", name: "Pinarello", price: 1800, oldPrice: 2000, discount: "10% OFF", img: require("../assets/images/1.png"), desc: "High quality Pinarello bike for road lovers." },
  { id: "2", name: "Pina Mountain", price: 1499, oldPrice: 1700, discount: "15% OFF", img: require("../assets/images/2.png"), desc: "Perfect for mountain and adventure rides." },
  { id: "3", name: "Pina Bike", price: 1300, oldPrice: 1500, discount: "12% OFF", img: require("../assets/images/3.png"), desc: "Stylish and durable everyday bike." },
  { id: "4", name: "Pinarello Pro", price: 1700, oldPrice: 1900, discount: "12% OFF", img: require("../assets/images/4.png"), desc: "Lightweight and strong for professionals." },
  { id: "5", name: "Pinarello X", price: 2100, oldPrice: 2400, discount: "12% OFF", img: require("../assets/images/3.png"), desc: "Premium bike for stylish riders." },
  { id: "6", name: "Pinarello Lite", price: 1200, oldPrice: 1350, discount: "12% OFF", img: require("../assets/images/2.png"), desc: "Affordable and durable choice." },
];

export default function ProductScreen({ navigation }) {
  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => navigation.navigate("ProductDetailScreen", { product: item })}
    >
      <View style={styles.imageBox}>
        <Image source={item.img} style={styles.image} resizeMode="contain" />
        <View style={styles.discountTag}>
          <Text style={styles.discountText}>{item.discount}</Text>
        </View>
      </View>
      <Text style={styles.name}>{item.name}</Text>
      <Text style={styles.price}>${item.price}</Text>
      <Text style={styles.oldPrice}>${item.oldPrice}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>The world’s Best Bike</Text>
      <FlatList
        data={bikes}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={{ justifyContent: "space-between" }}
        contentContainerStyle={{ paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", padding: 15 },
  title: { fontSize: 20, fontWeight: "bold", color: "red", marginBottom: 15, textAlign: "center" },
  card: {
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    padding: 10,
    marginBottom: 15,
    width: "48%",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 3,
  },
  imageBox: { position: "relative", marginBottom: 10 },
  image: { width: 120, height: 100 },
  discountTag: {
    position: "absolute",
    top: 5,
    right: 5,
    backgroundColor: "orange",
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 5,
  },
  discountText: { fontSize: 10, fontWeight: "bold", color: "#fff" },
  name: { fontSize: 14, fontWeight: "600", marginBottom: 5, textAlign: "center" },
  price: { fontSize: 14, color: "green", fontWeight: "bold" },
  oldPrice: { fontSize: 12, color: "#888", textDecorationLine: "line-through" },
});
