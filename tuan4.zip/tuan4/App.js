import React, { useState } from 'react';
import { ScrollView, View, StyleSheet } from 'react-native';
import ProductInfo from './components/ProductInfo';
import DiscountCode from './components/DiscountCode';
import TotalPrice from './components/TotalPrice';
import OrderButton from './components/OrderButton';

// Import image from assets
import bookImage from './assets/images/book.png';

const App = () => {
  const [quantity, setQuantity] = useState(1);
  const [discountCode, setDiscountCode] = useState('');
  const [temporaryTotal, setTemporaryTotal] = useState(141800);
  const [finalTotal, setFinalTotal] = useState(141800);

  const increaseQuantity = () => {
    const newQuantity = quantity + 1;
    setQuantity(newQuantity);
    setTemporaryTotal(141800 * newQuantity);
  };

  const decreaseQuantity = () => {
    const newQuantity = quantity > 1 ? quantity - 1 : 1;
    setQuantity(newQuantity);
    setTemporaryTotal(141800 * newQuantity);
  };

  const applyDiscount = () => {
    if (discountCode === 'SALE10') {
      const discountedPrice = temporaryTotal * 0.9;
      setFinalTotal(discountedPrice);
    } else {
      setFinalTotal(temporaryTotal);
      alert('Mã giảm giá không hợp lệ');
    }
  };

  const handleOrder = () => {
    alert('Đặt hàng thành công');
  };

  return (
    <ScrollView style={styles.container}>
      <ProductInfo
        imageSource={bookImage}
        price={141800}
        oldPrice={141800}
        title="Nguyên hàm tích phân và ứng dụng"
        quantity={quantity}
        onIncrease={increaseQuantity}
        onDecrease={decreaseQuantity}
      />
      <DiscountCode
        discountCode={discountCode}
        onDiscountChange={setDiscountCode}
        onApplyDiscount={applyDiscount}
      />
      <TotalPrice
        temporaryTotal={temporaryTotal}
        finalTotal={finalTotal}
      />
      <OrderButton onPress={handleOrder} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: '#f5f5f5',
  },
});

export default App;
