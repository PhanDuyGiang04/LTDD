import React from 'react';
import { View, TextInput, Text, Button, StyleSheet } from 'react-native';

const DiscountCode = ({ discountCode, onDiscountChange, onApplyDiscount }) => (
  <View style={styles.container}>
    <Text style={styles.label}>Mã giảm giá đã lưu</Text>
    <TextInput
      style={styles.input}
      value={discountCode}
      onChangeText={onDiscountChange}
      placeholder="Nhập mã giảm giá"
    />
    <Button title="Áp dụng" onPress={onApplyDiscount} />
  </View>
);

const styles = StyleSheet.create({
  container: {
    marginVertical: 15,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
  },
  label: {
    fontWeight: 'bold',
    marginBottom: 5,
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
  },
});

export default DiscountCode;
