import React from 'react';
import { Button, StyleSheet } from 'react-native';

const OrderButton = ({ onPress }) => (
  <Button title="TIẾN HÀNH ĐẶT HÀNG" onPress={onPress} color="red" />
);

export default OrderButton;
