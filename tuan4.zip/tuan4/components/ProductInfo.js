import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, TextInput } from 'react-native';

const ProductInfo = ({ imageSource, price, oldPrice, title, quantity, onIncrease, onDecrease, onBuyLater, discountCode, onDiscountChange, onApplyDiscount }) => (
  <View style={styles.container}>
    
    <View style={styles.productInfo}>
      
      <Image source={imageSource} style={styles.image} />

     
      <View style={styles.textContainer}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.subtitle}>Cung cấp bởi Tiki Trading</Text>

        <View style={styles.priceContainer}>
          <Text style={styles.price}>{price} đ</Text>
          <Text style={styles.oldPrice}>{oldPrice} đ</Text>
        </View>
      </View>
    </View>

    }
    <View style={styles.quantityAndBuyContainer}>
    
      <View style={styles.quantityRow}>
        <TouchableOpacity style={styles.button} onPress={onDecrease}>
          <Text>-</Text>
        </TouchableOpacity>
        <Text style={styles.quantityText}>{quantity}</Text>
        <TouchableOpacity style={styles.button} onPress={onIncrease}>
          <Text>+</Text>
        </TouchableOpacity>
      </View>

      
      <TouchableOpacity style={styles.buyLaterButton} onPress={onBuyLater}>
        <Text style={styles.buyLaterText}>Mua sau</Text>
      </TouchableOpacity>
    </View>

    
    <View style={styles.discountContainer}>
      <Text style={styles.discountLabel}>Mã giảm giá đã lưu</Text>
      <TextInput
        style={styles.discountInput}
        placeholder="Nhập mã giảm giá"
        value={discountCode}
        onChangeText={onDiscountChange}
      />
      <TouchableOpacity style={styles.applyButton} onPress={onApplyDiscount}>
        <Text style={styles.applyButtonText}>Áp dụng</Text>
      </TouchableOpacity>
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    padding: 10,
    backgroundColor: '#fff',
    marginBottom: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  productInfo: {
    flexDirection: 'row', 
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  textContainer: {
    flex: 1,
    marginLeft: 10,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    color: '#777',
    marginBottom: 10,
  },
  priceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  price: {
    fontSize: 18,
    color: 'red',
    fontWeight: 'bold',
  },
  oldPrice: {
    fontSize: 16,
    color: '#999',
    textDecorationLine: 'line-through',
  },
  image: {
    width: 100,
    height: 130,
    resizeMode: 'contain',
  },
  quantityAndBuyContainer: {
    flexDirection: 'row', 
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 15,
  },
  quantityRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  button: {
    width: 30,
    height: 30,
    backgroundColor: '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 4,
  },
  quantityText: {
    fontSize: 16,
  },
  buyLaterButton: {
    backgroundColor: '#f8f8f8',
    padding: 10,
    marginLeft: 20,
    alignItems: 'center',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  buyLaterText: {
    fontSize: 14,
    color: '#007BFF',
  },
  discountContainer: {
    marginTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    paddingTop: 10,
  },
  discountLabel: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  discountInput: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginVertical: 10,
    paddingLeft: 10,
    borderRadius: 5,
  },
  applyButton: {
    backgroundColor: '#FFD700',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  applyButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default ProductInfo;
