import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const TotalPrice = ({ temporaryTotal, finalTotal }) => (
  <View style={styles.container}>
    <View style={styles.row}>
      <Text style={styles.label}>Tạm tính</Text>
      <Text style={styles.amount}>{temporaryTotal} đ</Text>
    </View>
    <View style={styles.row}>
      <Text style={styles.label}>Thành tiền</Text>
      <Text style={styles.amount}>{finalTotal} đ</Text>
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    marginVertical: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 5,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  amount: {
    fontSize: 16,
    color: 'red',
  },
});

export default TotalPrice;
