import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import ProductDetail from './screen/ProductDetail';
import ColorPicker from './screen/ColorPicker';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="ProductDetail">
        <Stack.Screen name="ProductDetail" component={ProductDetail} options={{ title: 'Chi tiết sản phẩm' }} />
        <Stack.Screen name="ColorPicker" component={ColorPicker} options={{ title: '4 Màu-Chọn màu' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
