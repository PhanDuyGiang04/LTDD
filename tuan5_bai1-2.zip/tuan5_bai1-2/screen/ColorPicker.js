// screens/ColorPicker.js
import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  StyleSheet,
  ActivityIndicator,
} from "react-native";

const MOCKAPI_URL = "https://68d4963b214be68f8c69aae4.mockapi.io/colors";

// ảnh local
const LOCAL_MAP = {
  "vs_blue.png": require("../assets/images/vs_blue.png"),
  "vs_red.png": require("../assets/images/vs_red.png"),
  "vs_black.png": require("../assets/images/vs_black.png"),
  "vs_silver.png": require("../assets/images/vs_silver.png"),
};

const getImageSource = (img) => {
  if (!img) return null;
  if (img.startsWith("http")) return { uri: img }; // link từ API
  if (LOCAL_MAP[img]) return LOCAL_MAP[img]; // ảnh local
  return { uri: img }; // fallback
};

export default function ColorPicker({ route, navigation }) {
  const { onSelectColor, currentSelection } = route.params || {};
  const [colors, setColors] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(MOCKAPI_URL)
      .then((res) => res.json())
      .then((data) => {
        setColors(data);
        const def =
          (currentSelection &&
            data.find((c) => c.name === currentSelection.name)) ||
          data[0];
        setSelected(def);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* ảnh preview */}
      <View style={styles.header}>
        <Image
          source={getImageSource(selected?.image)}
          style={styles.headerImage}
        />
        <Text style={styles.headerText}>
          Điện Thoại Vsmart Joy 3{"\n"}Hàng chính hãng
        </Text>
      </View>

      <Text style={styles.title}>Chọn một màu bên dưới:</Text>

      {/* danh sách màu */}
      <View style={styles.colorList}>
        {colors.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={[
              styles.colorBox,
              { backgroundColor: item.code },
              selected?.id === item.id && styles.activeBox,
            ]}
            onPress={() => setSelected(item)}
          />
        ))}
      </View>

      {/* nút XONG */}
      <TouchableOpacity
        style={styles.doneButton}
        onPress={() => {
          if (typeof onSelectColor === "function") {
            onSelectColor(selected.name, selected.image);
          }
          navigation.goBack();
        }}
      >
        <Text style={styles.doneText}>XONG</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#ccc", padding: 20 },
  header: { flexDirection: "row", alignItems: "center", marginBottom: 12 },
  headerImage: {
    width: 80,
    height: 100,
    resizeMode: "contain",
    marginRight: 10,
  },
  headerText: { fontSize: 16, fontWeight: "500", flexShrink: 1 },
  title: { fontSize: 16, marginBottom: 12, textAlign: "center" },
  colorList: { alignItems: "center", marginBottom: 20 },
  colorBox: {
    width: 120,
    height: 120,
    borderRadius: 8,
    marginVertical: 10,
  },
  activeBox: { borderWidth: 4, borderColor: "#333" },
  doneButton: {
    backgroundColor: "#3F51B5",
    paddingVertical: 12,
    borderRadius: 6,
    alignItems: "center",
  },
  doneText: { color: "#fff", fontSize: 16, fontWeight: "bold" },
  loading: { flex: 1, justifyContent: "center", alignItems: "center" },
});
