import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';

const LOCAL_MAP = {
  "vs_blue.png": require("../assets/images/vs_blue.png"),
  "vs_red.png": require("../assets/images/vs_red.png"),
  "vs_black.png": require("../assets/images/vs_black.png"),
  "vs_silver.png": require("../assets/images/vs_silver.png"),
};

const getImageSource = (img) => {
  if (!img) return null;
  if (typeof img === "number") return img;
  if (img.startsWith("http")) return { uri: img };
  if (LOCAL_MAP[img]) return LOCAL_MAP[img];
  return { uri: img };
};

export default function ProductDetail({ navigation }) {
  const [selectedColor, setSelectedColor] = useState("Xanh");
  const [selectedImage, setSelectedImage] = useState(require('../assets/images/vs_blue.png'));

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        {/* Ảnh sản phẩm */}
        <Image 
          source={selectedImage} 
          style={styles.productImage} 
        />

        {/* Tên sản phẩm */}
        <Text style={styles.productName}>
          Điện Thoại Vsmart Joy 3 - Hàng chính hãng
        </Text>

        {/* Đánh giá sao */}
        <View style={styles.ratingRow}>
          {[...Array(5)].map((_, i) => (
            <Icon 
              key={i} 
              name="star" 
              size={18} 
              color={i < 4 ? "#FFD700" : "#ccc"} 
              style={{ marginRight: 2 }}
            />
          ))}
          <Text style={styles.reviewText}>(Xem 828 đánh giá)</Text>
        </View>

        {/* Giá */}
        <View style={styles.priceRow}>
          <Text style={styles.newPrice}>1.790.000 ₫</Text>
          <Text style={styles.oldPrice}>1.790.000 ₫</Text>
        </View>

        {/* Ghi chú */}
        <Text style={styles.note}>
          Ở ĐÂU RẺ HƠN HOÀN TIỀN
        </Text>

        {/* Nút chọn màu */}
        <TouchableOpacity 
          style={styles.colorButton}
          onPress={() => navigation.navigate("ColorPicker", {
            currentSelection: { name: selectedColor, image: selectedImage },
            onSelectColor: (name, img) => {
              setSelectedColor(name);
              setSelectedImage(getImageSource(img));
            }
          })}
        >
          <Text style={styles.colorText}>4 MÀU - CHỌN MÀU ({selectedColor}) ></Text>
        </TouchableOpacity>

        {/* Nút mua */}
        <TouchableOpacity style={styles.buyButton}>
          <Text style={styles.buyText}>CHỌN MUA</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", justifyContent: "center", alignItems: "center" },
  card: { borderWidth: 1, borderColor: "#FFD54F", padding: 15, borderRadius: 8, width: 300, alignItems: "center", backgroundColor: "#fff" },
  productImage: { width: 200, height: 250, resizeMode: 'contain' },
  productName: { fontSize: 16, marginTop: 8, textAlign: "center" },
  ratingRow: { flexDirection: "row", alignItems: "center", marginTop: 5 },
  reviewText: { marginLeft: 5, fontSize: 12, color: "#333" },
  priceRow: { flexDirection: "row", alignItems: "center", marginTop: 8 },
  newPrice: { color: "red", fontSize: 18, fontWeight: "bold", marginRight: 10 },
  oldPrice: { textDecorationLine: "line-through", color: "#888" },
  note: { color: "red", fontSize: 12, marginTop: 6 },
  colorButton: { borderWidth: 1, borderColor: "#ccc", padding: 10, borderRadius: 6, width: "100%", alignItems: "center", marginTop: 10 },
  colorText: { fontSize: 14, color: "#333" },
  buyButton: { backgroundColor: "red", padding: 12, borderRadius: 6, width: "100%", alignItems: "center", marginTop: 12 },
  buyText: { color: "#fff", fontSize: 16, fontWeight: "bold" }
});
