import React, { useState } from "react";
import { View, TextInput, StyleSheet, Text } from "react-native";

export default function SearchScreen() {
  const [keyword, setKeyword] = useState("");

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Nhập từ khóa tìm kiếm:</Text>
      <TextInput
        style={styles.input}
        placeholder="Nhập ở đây..."
        value={keyword}
        onChangeText={setKeyword}
      />
      <Text style={styles.result}>Bạn đang tìm: {keyword}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  label: { fontSize: 16, marginBottom: 8 },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  result: { fontSize: 16, color: "blue" },
});
